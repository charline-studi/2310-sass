# themes

On met ici tous les fichiers de styles qui permettrons de mettre en place des thèmes.
Ce dossier est optionnel.

Exemples :

- un thème par default
- un thème "administrateur"
- un darkmode
- un mode sans animation
- ...

# page

On met ici tous les fichiers de styles pour les différentes pages de notre site.
Chaque page peut avoir des spécificités : une couleur de fond différente, des éléments html qui ne sont pas vraiment des composants.

Exemples :

- page d'accueil
- page mentions légales
- page de contact
- ...

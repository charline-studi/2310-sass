# components

On met ici tous les fichiers de styles pour chacun de nos composants.
On doit avoir un fichier par composant.
Un composant est un bloc de code indépendant qui peut être ré-utilisé.

Exemples :

- un bouton
- un carrousel
- un formulaire de contact
- une carte de géolocalisation
- ...

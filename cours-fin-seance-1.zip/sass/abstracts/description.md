# absctracts

On met ici tous les fichiers utilitaires, c'est-à-dire les bouts code que l'on va utiliser dans d'autres fichiers sass.
Le code ici n'est pas "lié" à du HTML, c'est un code purement fonctionnel.
Ce dossier est parfois nommé "utils".

Exemples :

- les variables
- les fonctions
- les mixins
- les extends
- ...

# base

On met ici tous les fichiers de styles qui servent de "base" c'est-à-dire :

- tous les codes qui sont utilés pour tout notre site
- et qui doivent chargés en premier

Exemples :

- le code pour effacer le style par défaut des navigateurs : \_reset.sass
- le code pour importer des fonts
- ...
